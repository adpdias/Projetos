These are the before and after solutions for
Pluralsight.com
 Entity Framework Core: Getting Started (EF Core 3.1 update) by Julie Lerman
Created in Visual Studio 2019
Module9: Automated testing with EF Core

There are 3 solutions.
1) The console app before 
2) The console app with tests after
3) The ASP.NET Core app with tests. You will not be adding anything to this solution.